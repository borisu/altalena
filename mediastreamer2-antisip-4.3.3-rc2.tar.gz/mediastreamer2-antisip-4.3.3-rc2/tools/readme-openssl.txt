To compile openssl, follow instruction
and MODIFY first flag of ms/nt.mak to compile
with /MT flag

CFLAG= /MT

